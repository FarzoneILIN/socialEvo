#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多 Agent 实验 —— 任务三：渔民一片湖捕鱼
========================================

两个智能体 A、B 共用一片湖泊。初始鱼量 100，模拟 5 个回合，每回合流程：
  1) 讨论阶段：A、B 简短对话，商量捕鱼量；
  2) 决策阶段：A、B 秘密输出各自捕获量（0~50 的整数）；
  3) 结算阶段：扣除总捕捞量，剩余鱼量按 1.2 倍增长（上限 100）。
     若鱼量归 0 则提前结束。

容错设计：
  - 严格正则解析：优先匹配“捕捞 X 条 / X 条 / 中文数字”等格式；
  - 兜底逻辑（Fallback）：解析失败时使用保守默认值，绝不崩溃；
  - LLM 可插拔：默认使用模拟 LLM（无需 API Key，演示容错），
    设置 OPENAI_API_KEY 后自动切换真实 OpenAI 兼容接口，接口异常同样回退。

运行：python main.py
实验完整对话与数据保存为 fish_experiment_log.json。
"""

import argparse
import json
import os
import random
import re
import sys
import urllib.error
import urllib.request
from datetime import datetime

# 让 Windows 控制台也能正常打印中文
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# ---------------------------------------------------------------------------
# 全局实验参数
# ---------------------------------------------------------------------------
INITIAL_FISH = 100      # 初始鱼量
MAX_CATCH = 50          # 单 Agent 单回合捕获上限
ROUNDS = 5              # 回合数
GROWTH_RATE = 1.2       # 剩余鱼量增长倍率
FISH_CAP = 100          # 鱼量上限
FALLBACK_CATCH = 5      # 解析失败时的保守兜底捕获量

# ---------------------------------------------------------------------------
# 中文数字（0~99）解析
# ---------------------------------------------------------------------------
CN_DIGIT = {"零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
            "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}


def cn_numeral_to_int(text):
    """把中文数字转成整数，无法识别返回 None。"""
    s = (text or "").strip()
    if not s:
        return None
    if s in CN_DIGIT:
        return CN_DIGIT[s]
    if s in ("十", "一十"):
        return 10
    if s == "二十":
        return 20
    if s.startswith("十") and len(s) == 2 and s[1] in CN_DIGIT:
        return 10 + CN_DIGIT[s[1]]          # 十一 ~ 十九
    if s.endswith("十") and len(s) == 2 and s[0] in CN_DIGIT:
        return CN_DIGIT[s[0]] * 10          # 二十 ~ 九十
    if len(s) == 3 and s[1] == "十" and s[0] in CN_DIGIT and s[2] in CN_DIGIT:
        return CN_DIGIT[s[0]] * 10 + CN_DIGIT[s[2]]  # 二十一 ~ 九十九
    return None


# ---------------------------------------------------------------------------
# 严格正则解析 + 兜底逻辑
# ---------------------------------------------------------------------------
def parse_catch_number(text):
    """严格解析捕获量（0~50 整数）。

    返回 (value:int, source:str, matched:str|None)。
    source 取值：'regex'（正则命中）或 'fallback'（兜底）。
    无论输入多么离谱，这里绝不抛异常。
    """
    if text is None:
        return FALLBACK_CATCH, "fallback", None

    t = str(text).strip()
    candidates = []  # (命中方式, 数值)

    # 1) 动作关键词 + 数字：捕捞/捕获/捕鱼/捕/捞 12 [条]
    for m in re.finditer(r"(?:捕捞|捕获|捕鱼|捕|捞|打捞)\s*[:：]?\s*(\d{1,3})\s*(?:条|只|尾|鱼)?", t):
        candidates.append(("动作+数字", int(m.group(1))))

    # 2) 数字 + 单位：12 条 / 12 只 / 12 尾 / 12 条鱼
    for m in re.finditer(r"(?<!\d)(\d{1,3})\s*(?:条|只|尾|条鱼|尾鱼)", t):
        candidates.append(("数字+单位", int(m.group(1))))

    # 3) 标签 + 数字：决定/输出/我选/捕获量/amount/catch = 12
    for m in re.finditer(r"(?:决定|输出|我选|选择|捕捞量|捕获量|amount|catch)\s*[:：=]?\s*(\d{1,3})", t, re.IGNORECASE):
        candidates.append(("标签+数字", int(m.group(1))))

    # 4) 中文数字（零~九十九）
    for m in re.finditer(r"[零一两二三四五六七八九十]{1,3}", t):
        v = cn_numeral_to_int(m.group(0))
        if v is not None and 0 <= v <= 99:
            candidates.append(("中文数字", v))

    # 5) 宽松兜底：任意 0~999 的整数
    for m in re.finditer(r"(?<!\d)(\d{1,3})(?!\d)", t):
        candidates.append(("任意整数", int(m.group(1))))

    if candidates:
        tag, value = candidates[0]
        if value < 0:
            value = 0
        if value > MAX_CATCH:
            return MAX_CATCH, "regex", f"{tag}={value}(clamped->{MAX_CATCH})"
        return value, "regex", f"{tag}={value}"

    # 所有正则都失败 -> 兜底，绝不让程序崩溃
    return FALLBACK_CATCH, "fallback", None


# ---------------------------------------------------------------------------
# LLM 客户端（可插拔）
# ---------------------------------------------------------------------------
class LLMError(Exception):
    """LLM 调用异常，统一捕获。"""


class MockLLM:
    """模拟大模型：无需联网，返回合理（偶尔故意乱码）的回复。

    乱码回复用于在真实运行中触发“正则解析失败 -> 兜底”的容错路径，
    证明程序不会因大模型返回非数字内容而崩溃。
    """

    def __init__(self, rng):
        self.rng = rng
        self._decision_count = 0

    def chat(self, messages, **kwargs):
        system = ""
        last_user = ""
        for m in messages:
            if m.get("role") == "system":
                system = m.get("content", "")
            if m.get("role") == "user":
                last_user = m.get("content", "")
        is_decision = ("决策" in last_user) or ("输出" in last_user)
        if is_decision:
            return self._decision_reply(system)
        return self._discussion_reply(system, last_user)

    def _fish_from(self, text):
        m = re.search(r"鱼量[:：]?\s*(\d{1,3})", text)
        if m:
            return int(m.group(1))
        m = re.search(r"湖中还有\s*(\d{1,3})", text)
        return int(m.group(1)) if m else None

    def _greedy(self, system):
        return ("激进" in system) or ("短视" in system)

    def _discussion_reply(self, system, prompt):
        fish = self._fish_from(prompt) or INITIAL_FISH
        if self._greedy(system):
            n = min(MAX_CATCH, max(0, self.rng.randint(30, 45)))
            return (f"湖里还有 {fish} 条，机会难得，我想多捕一点，"
                    f"这回合我打算捕 {n} 条，你也别客气。")
        n = min(MAX_CATCH, max(0, self.rng.randint(4, 12)))
        return (f"现在湖里有 {fish} 条，为了可持续，我建议我们都克制点，"
                f"我这回合先捕 {n} 条左右，留足繁殖的鱼。")

    def _decision_reply(self, system):
        self._decision_count += 1
        # 第一次决策故意返回非数字内容，确保真实运行中触发一次“兜底”路径
        if self._decision_count == 1 or self.rng.random() < 0.15:
            return "我觉得应该保护湖泊，慢慢来。"
        if self._greedy(system):
            n = min(MAX_CATCH, max(0, self.rng.randint(28, 50)))
        else:
            n = min(MAX_CATCH, max(0, self.rng.randint(5, 15)))
        style = self.rng.choice(["我决定捕捞 {n} 条。", "捕{n}条吧。", "amount: {n}"])
        return style.format(n=n)


class OpenAICompatLLM:
    """真实 OpenAI 兼容接口（使用标准库 urllib，无需第三方依赖）。"""

    def __init__(self, api_key, base_url=None, model=None, timeout=60):
        self.api_key = api_key
        self.base_url = (base_url or os.environ.get("OPENAI_BASE_URL")
                         or "https://api.openai.com/v1").rstrip("/")
        self.model = model or os.environ.get("OPENAI_MODEL") or "gpt-4o-mini"
        self.timeout = timeout

    def chat(self, messages, temperature=0.7, max_tokens=256):
        url = f"{self.base_url}/chat/completions"
        payload = json.dumps({
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }).encode("utf-8")
        req = urllib.request.Request(url, data=payload, headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        })
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            return data["choices"][0]["message"]["content"]
        except (urllib.error.URLError, urllib.error.HTTPError,
                KeyError, IndexError, ValueError, TimeoutError) as exc:
            raise LLMError(f"LLM 接口调用失败: {exc}")


def build_llm(rng):
    """根据环境变量决定使用真实接口还是模拟接口。"""
    api_key = os.environ.get("OPENAI_API_KEY") or os.environ.get("LLM_API_KEY")
    if api_key:
        return OpenAICompatLLM(api_key)
    return MockLLM(rng)


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------
AGENT_A_SYSTEM = (
    "你是一位渔民，代号 A。你的性格：注重可持续发展，倾向克制捕捞，为来年留鱼。"
    f"规则：初始鱼量 {INITIAL_FISH}，每回合每人可捕 0~{MAX_CATCH} 条，"
    f"剩余鱼量按 {GROWTH_RATE} 倍增长但上限 {FISH_CAP}。鱼量归 0 则实验结束。"
    "请用简体中文简短回答。"
)
AGENT_B_SYSTEM = (
    "你是一位渔民，代号 B。你的性格：短视激进，倾向尽量多捕。"
    f"规则：初始鱼量 {INITIAL_FISH}，每回合每人可捕 0~{MAX_CATCH} 条，"
    f"剩余鱼量按 {GROWTH_RATE} 倍增长但上限 {FISH_CAP}。鱼量归 0 则实验结束。"
    "请用简体中文简短回答。"
)


class Agent:
    def __init__(self, name, persona, system_prompt, llm):
        self.name = name
        self.persona = persona
        self.system_prompt = system_prompt
        self.llm = llm

    def discuss(self, round_no, fish):
        prompt = (f"【讨论阶段 第{round_no}回合】当前湖中鱼量:{fish}。"
                  f"请发表一句话，和另一位渔民商量本回合你们各自捕多少鱼"
                  f"（每人 0~{MAX_CATCH} 条）。")
        return self._safe_call([
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": prompt},
        ])

    def decide(self, round_no, fish):
        prompt = (f"【决策阶段 第{round_no}回合】当前湖中鱼量:{fish}。"
                  f"请秘密输出你本回合的捕获量（0~{MAX_CATCH} 的整数）。")
        raw = self._safe_call([
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": prompt},
        ])
        value, source, matched = parse_catch_number(raw)
        return {"raw": raw, "value": value, "source": source, "matched": matched}

    def _safe_call(self, messages):
        try:
            text = self.llm.chat(messages)
            return text if text else "(空回复)"
        except Exception as exc:  # 任何异常都兜底，不让程序崩溃
            return f"(LLM 调用异常，已兜底: {exc})"


def apply_growth(n):
    """按 1.2 倍增长（四舍五入，0.5 进位）。"""
    return int(n * GROWTH_RATE + 0.5)


# ---------------------------------------------------------------------------
# 主实验流程
# ---------------------------------------------------------------------------
def run_experiment(seed=42, rounds=ROUNDS):
    rng = random.Random(seed)
    llm = build_llm(rng)
    agents = [
        Agent("A", "合作/可持续", AGENT_A_SYSTEM, llm),
        Agent("B", "激进/短视", AGENT_B_SYSTEM, llm),
    ]

    fish = INITIAL_FISH
    round_logs = []
    ended_early = False
    use_real = isinstance(llm, OpenAICompatLLM)

    print("=" * 70)
    print(f"多 Agent 实验【任务三：渔民一片湖捕鱼】  seed={seed}")
    print(f"初始鱼量={INITIAL_FISH}  回合数={rounds}  单次上限={MAX_CATCH}  "
          f"增长率={GROWTH_RATE}x  上限={FISH_CAP}")
    print(f"LLM 后端: {'OpenAI 兼容接口' if use_real else 'MockLLM（模拟，演示容错）'}")
    print("=" * 70)

    for r in range(1, rounds + 1):
        print(f"\n--- 第 {r} 回合 | 湖中鱼量: {fish} ---")

        # 1) 讨论阶段
        discussion = []
        for a in agents:
            msg = a.discuss(r, fish)
            discussion.append({"agent": a.name, "content": msg})
            print(f"  [{a.name}] {msg}")

        # 2) 决策阶段（秘密，互不可见）
        decisions = {}
        for a in agents:
            d = a.decide(r, fish)
            decisions[a.name] = d
            print(f"  [决策·{a.name}] 原始输出: {d['raw']!r}")
            extra = f", {d['matched']}" if d["matched"] else ""
            print(f"  [决策·{a.name}] 解析结果: 捕获 {d['value']} 条 "
                  f"(来源: {d['source']}{extra})")

        total_catch = sum(d["value"] for d in decisions.values())
        before = fish

        # 3) 结算阶段
        fish_after_catch = max(0, before - total_catch)
        extinct = fish_after_catch <= 0
        if extinct:
            fish = 0
        else:
            fish = min(FISH_CAP, apply_growth(fish_after_catch))

        print(f"  [结算] 总捕捞 {total_catch} 条 -> 剩余 {fish_after_catch} 条 -> "
              f"增长后 {fish} 条" + ("（鱼量归 0，提前结束）" if extinct else ""))

        round_logs.append({
            "round": r,
            "fish_before": before,
            "discussion": discussion,
            "decisions": decisions,
            "total_catch": total_catch,
            "fish_after_catch": fish_after_catch,
            "growth_applied": (fish - fish_after_catch) if not extinct else 0,
            "fish_after_round": fish,
            "extinct": extinct,
        })

        if extinct:
            ended_early = True
            break

    log = {
        "experiment": "task3_lake_fishing",
        "config": {
            "initial_fish": INITIAL_FISH,
            "max_catch": MAX_CATCH,
            "rounds": rounds,
            "growth_rate": GROWTH_RATE,
            "fish_cap": FISH_CAP,
            "fallback_catch": FALLBACK_CATCH,
            "seed": seed,
        },
        "llm_backend": "openai" if use_real else "mock",
        "agents": [{"name": a.name, "persona": a.persona,
                    "system_prompt": a.system_prompt} for a in agents],
        "started_at": datetime.now().isoformat(timespec="seconds"),
        "rounds": round_logs,
        "rounds_played": len(round_logs),
        "final_fish": fish,
        "ended_early": ended_early,
    }
    log["ended_at"] = datetime.now().isoformat(timespec="seconds")
    return log


def main(argv=None):
    parser = argparse.ArgumentParser(description="多 Agent 实验：渔民一片湖捕鱼")
    parser.add_argument("--seed", type=int, default=42, help="随机种子（默认 42）")
    parser.add_argument("--rounds", type=int, default=ROUNDS, help="回合数（默认 5）")
    parser.add_argument("--out", default="fish_experiment_log.json", help="日志输出文件")
    parser.add_argument("--selftest", action="store_true", help="仅运行容错逻辑自检")
    args = parser.parse_args(argv)

    if args.selftest:
        return selftest()

    log = run_experiment(seed=args.seed, rounds=args.rounds)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(log, f, ensure_ascii=False, indent=2)

    print("\n" + "=" * 70)
    print(f"实验结束。最终鱼量: {log['final_fish']} 条；"
          f"进行回合数: {log['rounds_played']}；"
          f"提前结束: {'是' if log['ended_early'] else '否'}")
    print(f"完整日志已保存 -> {os.path.abspath(args.out)}")
    print("=" * 70)
    return 0


def selftest():
    """验证严格正则解析与兜底逻辑。"""
    print("运行容错逻辑自检...")
    cases = [
        ("我决定捕捞 12 条。", 12, "regex"),
        ("捕18条吧。", 18, "regex"),
        ("amount: 20", 20, "regex"),
        ("我捕十条。", 10, "regex"),
        ("我捕十五尾。", 15, "regex"),
        ("捕捞 60 条（超上限）", 50, "regex"),
        ("我觉得应该保护湖泊，慢慢来。", FALLBACK_CATCH, "fallback"),
        ("", FALLBACK_CATCH, "fallback"),
        (None, FALLBACK_CATCH, "fallback"),
        ("随便写点没有数字的话", FALLBACK_CATCH, "fallback"),
    ]
    ok = True
    for text, expect_val, expect_src in cases:
        val, src, matched = parse_catch_number(text)
        good = (val == expect_val and src == expect_src)
        ok = ok and good
        print(f"  {'PASS' if good else 'FAIL'}  {text!r:40} -> "
              f"value={val} source={src} matched={matched!r}")

    # 结算逻辑自检
    fish = 100
    after = max(0, fish - 15 - 10)
    grown = min(FISH_CAP, apply_growth(after))
    assert after == 75 and grown == 90, "growth/settle 错误"
    print("  PASS  结算逻辑：100 - 25 = 75 -> 75*1.2=90 -> 90（未到上限）")

    print("自检结果:", "全部通过" if ok else "存在失败")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
