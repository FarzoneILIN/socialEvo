# -*- coding: utf-8 -*-
"""批量运行 10 组实验（每组 10 轮），汇总结果供报告使用。"""
import io
import json
import contextlib
import main


def run_batch(n=10, rounds=10):
    results = []
    for seed in range(n):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            log = main.run_experiment(seed=seed, rounds=rounds)

        rp = log["rounds_played"]
        a_total = sum(r["decisions"]["A"]["value"] for r in log["rounds"])
        b_total = sum(r["decisions"]["B"]["value"] for r in log["rounds"])
        a_fb = sum(1 for r in log["rounds"] if r["decisions"]["A"]["source"] == "fallback")
        b_fb = sum(1 for r in log["rounds"] if r["decisions"]["B"]["source"] == "fallback")

        results.append({
            "seed": seed,
            "rounds_played": rp,
            "final_fish": log["final_fish"],
            "ended_early": log["ended_early"],
            "A_total": a_total,
            "B_total": b_total,
            "A_avg": round(a_total / rp, 2) if rp else 0.0,
            "B_avg": round(b_total / rp, 2) if rp else 0.0,
            "A_fallback": a_fb,
            "B_fallback": b_fb,
            "rounds": [
                {
                    "round": r["round"],
                    "fish_before": r["fish_before"],
                    "A": r["decisions"]["A"]["value"],
                    "B": r["decisions"]["B"]["value"],
                    "A_src": r["decisions"]["A"]["source"],
                    "B_src": r["decisions"]["B"]["source"],
                    "total": r["total_catch"],
                    "fish_after": r["fish_after_round"],
                }
                for r in log["rounds"]
            ],
        })

    with open("fish_experiment_batch.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # 汇总统计
    all_rounds = sum(r["rounds_played"] for r in results)
    all_a = sum(r["A_total"] for r in results)
    all_b = sum(r["B_total"] for r in results)
    early = sum(1 for r in results if r["ended_early"])
    fb_total = sum(r["A_fallback"] + r["B_fallback"] for r in results)

    print(f"{'seed':>4} {'rounds':>6} {'final':>5} {'A_total':>7} {'B_total':>7} "
          f"{'A_avg':>6} {'B_avg':>6} {'A_fb':>4} {'B_fb':>4}")
    for r in results:
        print(f"{r['seed']:>4} {r['rounds_played']:>6} {r['final_fish']:>5} "
              f"{r['A_total']:>7} {r['B_total']:>7} {r['A_avg']:>6} {r['B_avg']:>6} "
              f"{r['A_fallback']:>4} {r['B_fallback']:>4}")

    print("---")
    print(f"组数={len(results)}  每组设定回合={rounds}")
    print(f"平均实际进行回合={round(all_rounds / len(results), 2)}")
    print(f"提前结束组数={early}/{len(results)}")
    print(f"A 总捕捞={all_a}  B 总捕捞={all_b}  B/A 收益比={round(all_b / all_a, 2)}")
    print(f"A 总体平均/回合={round(all_a / all_rounds, 2)}  B 总体平均/回合={round(all_b / all_rounds, 2)}")
    print(f"兜底决策总次数={fb_total}/{2 * all_rounds} (占比 {round(fb_total / (2 * all_rounds) * 100, 1)}%)")
    return results


if __name__ == "__main__":
    run_batch(10, 10)
